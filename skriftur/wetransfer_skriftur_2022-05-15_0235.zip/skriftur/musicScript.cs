using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class musicScript : MonoBehaviour
{
    // Start is called before the first frame update
    public AudioSource utiHljod;
    public AudioSource hellaHljod;
    public AudioSource bossHljod;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
